using namespace std;

class DLLNode
{
public:
	int nodeVal;
	DLLNode *fPtr;
	DLLNode *rPtr;
public:
	DLLNode() {};
	DLLNode(int v);
	int getVal();
	void setVal();
}; // class DLLNode

class DLList
{
public:
	DLLNode *header;
	DLLNode *trailer;
	int lcount;
public:
	DLList();
	~DLList();
	void addDNodeFront(DLLNode *nodeVal);