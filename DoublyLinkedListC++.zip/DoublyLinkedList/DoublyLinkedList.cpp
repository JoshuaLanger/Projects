#include "DoublyLinkedListHeader.h"

// below include the codes which manage the doubly linked list
DLList::DLList()
{
	header = NULL;
	trailer = NULL;			// set header and trailer as blank nodes
	lcount = 0;				// set list count to zero as there are no initial nodes
} // end doubly linked list constructor

DLList::~DLList()
{
	while (!(listEmpty())) {delDNodeFront(); }
	delete header;
	delete trailer;
	lcount = 0;
} // ~DLList()

void DLList::addDNodeFront(DNode *dN)
{
	dN->fptr = header;		// set dN to before header
	header = dN;			// set header to dN
	lcount++;				// increment list count
} // addDNodeFront(DNode *n)

void DLList::delDNodeFront()
{
	DNode *hN = header;		// find the header and assign variable node to it
	header = hN->fptr;		// move the header to the second node
	delete hN;				// delete first node
	lcount--;				// decrement list count
} // delDNodeFront()

void DLList::addDNodeEnd(DNode *dN)
{
	DNode *hN = header;
	DNode *tN = trailer;	// store special nodes in temporary nodes
	DNode *tempNode = NULL; // designate a temporary node

	if (hN == NULL)
	{
		header = dN;
		trailer = dN;		// if first node, set header and trailer as node together 
	}
	else
	{
		dN->rptr = tN;		// have new node point to trailer variable
		tN->fptr = dN;		// have trailer variable point back to new node
		trailer = dN;		// set trailer to new node
	}
	lcount++;				// increment list count
} // addDNodeEnd()

void DLList::delDNodeEnd()
{
	DNode *tN = trailer;	// find the trailer and assign variable node to it
	trailer = tN->rptr;		// move the trailer to the second to last node
	trailer->fptr = NULL;	// assure that the trailer is the last node in the list
	delete tN;				// severed of links, delete last node
	lcount--;				// decrement list count
} // delDNodeEnd()

void DLList::insertDNode(DNode *dN)
{
	//This function inserts a node which value is greater than that of dN and less than that of tN
	DNode *rN = header;
	DNode *fN = rN->fptr;

	// is value of rN less than value of dN AND value of dN is less than value of fN?
	while (!((rN->payload <= dN->payload) && (dN->payload <= fN->payload)))  
	{
		// "No" 
		rN = fN;
		if (fN->fptr == NULL) break;	// rN and fN are at end of list: no more numbers to compare
		fN = fN->fptr;		// switch rN and fN to next nodes
	} // while loop

	if (rN->fptr != NULL)	// tests if at end of list
	{
		// "Yes"
		dN->fptr = fN;
		dN->rptr = rN;		// dN points to rN and fN
		fN->rptr = dN;
		rN->fptr = dN;		// rN and fN point to dN
		lcount++;			// increment list count
	}
	else
	{
		// is value of dN greater than value at trailer?
		if (dN->payload > trailer->payload) {addDNodeEnd(dN);} // "Yes"
		else {addDNodeFront(dN);} // "No"
	}

} // insertDNode(DNode *n)

void DLList::delDNode(int n)
{
	// finds and deletes the first node with payload "n"
	
	DNode *dN = header;			// start at front of list
	while (dN->payload != n)	
	{
		if (dN->fptr == NULL) break; // at end of list: node could not be found
		dN = dN->fptr;			// switch to next node
	}
	if (dN->fptr != NULL)
	{
		DNode *rN = dN->rptr;
		DNode *fN = dN->fptr;	// create two nodes before and after dN
		rN->fptr = fN;			
		fN->rptr = rN;			// have nodes point to each other instead of dN
		delete dN;				// severed of linked, dN can be deleted
		lcount--;				// decrement list count
	}
	else		// when value is not in list
	{
		if (header->payload == n) {delDNodeFront(); }			// delete value at front of list
		else if (trailer->payload == n) {delDNodeEnd(); }		// delete value at end of list
		else {cout << "The node could not be found" << endl; }	
	}
		
} // delDNode(int n)

bool DLList::listEmpty() {return header == trailer == NULL; }	// same as empty list constructor

void DLList::printDLList()
{
	DNode *hN = header;			// start at header with variable node

	do
	{
		cout << hN->payload << endl;	// print integer value of node
		hN = hN->fptr;					// switch to next node
	} while (hN != NULL);				// terminating condition: a do-while loop ensures at least one integer is printed
	cout << "list count: " << lcount << endl;	// print list count
	cout << header << " " << trailer << endl;		// prints addresses of header and trailer
	cout << header->payload << " " << trailer->payload << endl;		// prints values of header and trailer
	cin.get(); 

} // printDLList()

void DLList::printReverseList() //successful test of reverse pointers
{
	DNode *tN = trailer;		// start at header with variable node

	do
	{
		cout << tN->payload << endl;	// print integer value of node
		tN = tN->rptr;					// switch to previous node
	} while (tN != NULL);				// terminating condition
	cout << "list count: " << lcount << endl;	// print list count
	cout << header << " " << trailer << endl;		// prints addresses of header and trailer
	cout << header->payload << " " << trailer->payload << endl;		// prints values of header and trailer
	cin.get(); 
} // printReverseList() 