#include <iostream>
using namespace std;

// First lets define a node type as discussed in class
// since the exercise is simple and for ease of coding lets have all 
// members be public

class DNode
{
public:
	DNode *fptr;				// forward pointer
	DNode *rptr;				// reverse pointer
	int payload;				// integer payload
	
	DNode(int i);				// prototype for the constructor
	DNode();					// no arg constructor
	//~DNode() {}; I found no need for this destructor as the DLList destructor deletes nodes

	int getPayload();			// prototype for the getter
	void setPayload(int i);		// prototype for the setter
}; // end class DNode

// now the class definition for the doubly linked list

class DLList
{
public:
	DNode *header;				// anchor node for the doubly linked list
	DNode *trailer;				// address of last node in the list
	int lcount;					// count of nodes in the list
	
	DLList();					// constructor for the doubly linked list
	~DLList();					// destructor for the doubly linked list

	void addDNodeFront(DNode *n);	// add a node to the front of the list
	void delDNodeFront();			// delet first node from the list
	void addDNodeEnd(DNode *n);		// add a node to the end of the list
	void delDNodeEnd();				// remove last node from the list
	void insertDNode(DNode *n);		// insert a node into the list
	void delDNode(int n);			// delete first node of payload=n from the list
	bool listEmpty();				// return true if list empty false otherwise
	void printDLList();				// print all elements of the list to the terminal
									// will also print header and trailer addresses and values
	
	void printReverseList();		// successful test of reverse pointers

}; // end of DLList class

