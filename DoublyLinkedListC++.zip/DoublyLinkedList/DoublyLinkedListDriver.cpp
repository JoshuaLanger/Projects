#include <iostream>
#include <cstdlib>
#include <ctime>
#include "DoublyLinkedListHeader.h"

/*
Your assignment is to use the following lines of code to 
populate your doubly linked list and then perform the operations on it as
indicated by the calls to the methods which comprise it.

Random numbers in this case will be seeded by a call to the ctime included 
header and should therefore be different for each user.

Use the singly linked list example worked in class as a guide and the codes
found in the text as a quide.

We have used pointers to structures in our course to pass values and structures
and accordingly you should use them here also.

This is a rather common assignment so I have little doubt that there are
"resources" available on the web. Please do not use these as anything other 
than a guide to the development of your solution. The benefit of this exercise 
lies more in the effort you put forth than a working "solution" developed by
someone else.

I will walk around the class toward the end of lecture on Tuesday and ask that 
you either demo your solution or alternatively explain where you got 
stumped.

Best of luck and enjoy.
Warren
*/

int main()
{
	// first lets declare some variables
	DLList *dll; // First the pointer to the doubly linked list
	int i;				// a counter variable
	int x;				// an interactive variable

	// 1. Create a doubly linked list object
	dll = new DLList();

	// first lets seed the random number generator with a call to the system clock
	srand( time(0));

	// using the random number generator create a doubly linked list with 10 random numbers
	for(i=0; i<10; i++)
	{
		dll->addDNodeEnd(new DNode(rand()));
	}

	cout << "Doubly linked list of 10 random numbers is created" << endl;
	cin.get(); 

	// Now print out your doubly linked list
	dll->printDLList();
	//Successful test to find the header and the trailer of the list, which should be
	//the first and last elements respectively
	
	// Now DELETE the first node in the list and print it out again
	dll->delDNodeFront();
	dll->printDLList();

	// Now DELETE the last node in the list and print the list again
	dll->delDNodeEnd();
	dll->printDLList();

	// Now ADD a new first node to the list and print the list again
	dll->addDNodeFront(new DNode(rand()));
	dll->printDLList();

	// Now ADD a new last node to the list and print the list again
	dll->addDNodeEnd(new DNode(rand()));
	dll->printDLList();

	// using the last print out, select a node to delete from the list and print the list again
	cout << "Choose an integer value to delete from the last list: ";
	cin >> x;
	dll->delDNode(x);
	dll->printDLList();

	// using the last print out, chose a an integer to add to the list
	cout << "\nEnter an integer value to insert into the last list: ";
	cin >> x;
	dll->insertDNode(new DNode(x));
	dll->printDLList();
	cin.get();

	// finally delete all memory from all nodes and the list and terminate your program
	// Destructors and while loops make nice tools for this purpose
	dll->~DLList();

} // end driver program
