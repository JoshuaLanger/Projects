#include "DoublyLinkedListHeader.h"

// now define the Node class members starting with the
// constructor
DNode::DNode(int i)
{
	fptr = NULL;
	rptr = NULL;
	payload = i;
} // end constructor

// you provide the rest of the code below
DNode::DNode() {}

int DNode::getPayload() {return payload;}

void DNode::setPayload(int p) {payload = p;}