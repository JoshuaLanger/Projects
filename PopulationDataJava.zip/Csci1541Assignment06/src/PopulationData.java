import java.util.Scanner;
import java.io.*;

/**
   This program demonstrates a solution to the
   Population Data programming challenge.
   * 
   * Student Name: Joshua Langer
   * Date: 4/18/13
   * 
*/

public class PopulationData
{
   public static void main(String[] args) throws IOException
   {
      // Constants for the array size.
      final int YEAR_START = 1950;
      final int YEAR_END = 1990;
      final int SIZE = (YEAR_END - YEAR_START) + 1;
      
      // Create two arrays to hold the population data and changes between elements.
      int[] population = new int[SIZE];
      int[] changes;
      int avg;
      int high;     // These three labels will help print out results
      int low;
      
      // Add elements from text file to array
      getDataFromFile(population, "USPopulation.txt");
      
      // Create another array based on the changes calculated from the population array
      changes = createChangesArray(population);
      
      // Get the average change
      avg = getAverageChange(changes);
      
      // Find the greatest increase
      high = getHighestIndex(changes);
      
      // Find the lowest index
      low = getLowestIndex(changes);
      
      System.out.println("Average change is: " + avg +
                         "\nHighest index is: " + high +
                         "\nLowest index is: " + low);
   }
   
   /**
      The getDataFromFile method populates an array of 
      integers with the values read from a file.
      @param array The array to reference the data.
      @param filename The name of a file containing data.
   */ 

   public static void getDataFromFile(int[] array, 
                        String filename) throws IOException
   {
      int index = 0; // Loop control variable
      int pop;      // Holds current population value
      // Open file
      File file = new File(filename);
      Scanner inFile = new Scanner(file);
   
      while (inFile.hasNext())
      {
          pop = inFile.nextInt(); // Retrieve the data from the text file...
          array[index] = pop;   //...and store it in the array
          index++;              // Increment index
      }
      inFile.close(); // close the file
   }  

   /**
    * createChangesArray method.
    * @param array An array of integers.
    */
   
   public static int[] createChangesArray(int[] array)
   {
       // Create a new array with one less the size of the original,
       // since only one less changes can be calculated
       int[] modArray = new int[array.length - 1];
       
       // Each element of modArray is equal to one element of the original array
       // minus the element in the previous index
       for (int i = 0; i < modArray.length; i++)
       {
           int c = array[i+1] - array[i]; // This will not cause an OutOfBounds exception
           modArray[i] = c; // Store the change in modArray
       }
       return modArray;
   }
   /**
      getTotalChange method.
      @param array An array of integers.
      @return The total of the change in the
		        values stored in the argument array.
   */
   
   public static int getTotalChange(int[] array)
   {
      // Initialize total at zero
      int total = 0;
      
      // Use a for loop to sum all elements in the array
      for (int i = 0; i < array.length; i++)
      {
          total += array[i];
      }
      return total;
   }
   
   /**
      getAverageChange method
      @param array An array of integers.
      @return The average change of the values 
		        stored in the argument array.
   */
   
   public static int getAverageChange(int[] array)
   {
      return getTotalChange(array) / array.length - 1;
   }
   
   /**
      getHighestIndex method
      @param array An array of integers.
      @return The index of the element with the 
		        greatest increase in the argument 
				  array.
   */
   
   public static int getHighestIndex(int[] array)
   {
      // Assume that the first element is the largest
      int index = array[0];
      // Use a for loop to traverse the array...
      for (int i = 0; i < array.length; i++)
      {
          //...and an if block to compare each element to index...
          if (array[i] > index) 
          {
              index = array[i]; //...and assign current element to index if true
          }
      }
      
      return index; // Is the largest element in the array
   }
   
   /**
      getHighestIndex method
      @param array An array of integers.
      @return The index of the element with the 
		        greatest increase in the argument 
				  array.
   */
   
   public static int getLowestIndex(int[] array)
   {
       // Assume that the first element is the smallest
      int index = array[0];
      // Use a for loop to traverse the array...
      for (int i = 0; i < array.length; i++)
      {
          //...and an if block to compare each element to index...
          if (array[i] < index) 
          {
              index = array[i]; //...and assign current element to index if true
          }
      }
      
      return index; // Is the smallest element in the array
   }       
}