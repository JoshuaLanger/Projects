from itertools import izip
import threading
import select
import socket
import time
import sys
import os

debug = 1 
clients = 10 #set how many clients can connect to this server (line 29)
host = ''
port = int(sys.argv[1])
SIZE = 1024

#function that scans the current working directory to find whether a desired file is within
def filecheck(path, file):
	directory = os.listdir(path)
	if debug:
		print directory
	for files in directory:
		if (file == files):
			return True
	return False

#thread function for communication with several clients and server
def clientthread(conn, addr):
	while 1:
		if debug:
			print str(addr)
		useraddr = socket.getfqdn(addr[0]) #returns key for table.txt
		if debug:
			print useraddr + "\n" + str(conn)
		password = conn.recv(8)
		if table.get(useraddr) == password:
			conn.sendall('ok')
			print '\nConnected with ' + useraddr
		else:
			conn.sendall('no')
			return
		while 1:
			client_message = conn.recv(64)
			if debug:
				print client_message
			strmes = str(client_message)
			client_command = strmes.split()
			if debug:
				print client_command

			#client sends upload command and filename for server to save to own directory
			if client_command[0] == 'upload':
				path = os.getcwd() + '/server'
				fullpath = os.path.join(path, client_command[1])
				if debug:
					print fullpath
				f = open(fullpath, 'wb')
				w = conn.recv(SIZE)
				if debug:
					print w
				f.write(w)
				f.close()
				conn.sendall('ok')

			#client requests file for server to send
			elif client_command[0] == 'download':
				path = os.getcwd() + '/server'
				if debug:
					print path
					print client_command
				#server first sees wether file exists in server directory or not
				if filecheck(path, client_command[1]) == False:
					print "This file does not exist in the current directory"
					#sends the failure to the client
					conn.sendall("no")
					continue
				conn.sendall("ok")
				fullpath = os.path.join(path, client_command[1])
				if debug:
					print fullpath
				f = open(fullpath, 'rb')
				r = f.read(SIZE)
				if debug:
					print r
				conn.sendall(r)
				f.close()

			elif client_command[0] == 'quit':
				conn.close()
				print "\nClosed connection with " + useraddr
				return	

			else:
				print 'Unknown command received'

#allows user to enter commands into the server terminal
def serverthread():
	while 1:
		server_command = raw_input("Enter a command or wait for a client: ")
		if str(server_command) == 'list':
			print '\nFiles in current working directory:\n'
			path = os.getcwd() + '/server'
			files = [ f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f)) ]
			for file in files:
				print file

		if str(server_command) == 'quit':
			if (threading.activeCount() > 2):
				print 'You cannot quit the server while clients are still connected.'
			else:
				print 'Now quitting.'
				#this actually doesn't quit to the command line. I have not figured out how to accomplish that.
				return

#convert table.txt to dictionary
f = open('table.txt', 'r')
data = [line.strip() for line in f]
i = iter(data)
table = dict(izip(i, i))
f.close()

#open socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Server socket created'

#bind to an address and port
try:
	s.bind((host, port))
except socket.error, msg:
	print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
	sys.exit()
print 'Server socket bind complete'

#listen for incoming connections
s.listen(clients)
print 'Server socket now listening'

#use threads to simultaneously command server and serve clients
servthread = threading.Thread(target = serverthread, args = ())
servthread.start()
while 1:
	if (threading.activeCount <= 2):
		break
	conn, addr = s.accept()
	clithread = threading.Thread(target = clientthread, args = (conn, addr))
	clithread.start()

s.close()
