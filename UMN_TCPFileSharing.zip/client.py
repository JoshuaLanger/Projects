from thread import *
import socket
import sys
import os

debug = 1
host = sys.argv[1]
port = int(sys.argv[2])
SIZE = 1024

#function that scans the current working directory to find whether a desired file is within
def filecheck(path, file):
	directory = os.listdir(path)
	if debug:
		print(directory)
	for files in directory:
		if (file == files):
			return True
	return False

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Client socket created')

#connect instead of bind
try:
	s.connect((host, port))
except socket.error, msg:
	print('Connection failed. This server doesn\'t exist.')
	sys.exit()
print('Client socket connect complete')

while 1:
	password = raw_input("Enter your password: ")
	s.sendall(password)
	reply = s.recv(64)
	if str(reply) == 'ok':
		#this confirmation is misleading, since the client was already connected
		print("That is the correct password! You are now connected.")
	elif str(reply) == 'no':
		print("That is NOT the correct password! You are now disconnected.")
		break
	else:
		print("Error in receiving server reply.")
	while 1:
		message = raw_input("Enter a command: ")
		strmes = str(message)
		command = strmes.split()
		if debug:
			print(command)
		if command[0] == 'help':
			print('\nupload [file name] [source folder]')
			print('download [file name] [dest folder]')
			print('list [source folder]')
			print('quit\n')
			continue
			
		if command[0] == 'upload' and command[1] and command[2]:
			path = os.getcwd() + '/' + command[2]
			if debug:
				filecheck(path, command[1])
			if filecheck(path, command[1]) == False:
				print("This file does not exist in the current directory. Try again.")
				continue
			#send the command and file-name to the server 
			s.sendall(command[0] + ' ' + command[1])
			fullpath = os.path.join(path, command[1])
			f = open(fullpath, 'rb')
			r = f.read(SIZE)
			if debug:
				print r
			s.sendall(r)
			f.close()
			reply = s.recv(8)
			if debug:
				print str(reply)
			if (str(reply) == "ok"):
				print("File successfully uploaded")

		elif command[0] == 'download' and command[1] and command[2]:
			send = command[0] + ' ' + command[1]
			if debug:
				print send
			s.sendall(send)
			reply = s.recv(8)
			if debug:
				print reply
			if (str(reply) == "no"):
				print("This file is not available in the server directory. Try again.")
				continue
			path = os.getcwd() + '/' + command[2]
			fullpath = os.path.join(path, command[1])
			if debug:
				print fullpath
 			f = open(fullpath, 'wb')
			w = s.recv(SIZE)
			if debug:
				print w
			f.write(w)
			f.close()
			print("File successfully downloaded")

		elif command[0] == 'list' and command[1]:
			print('\nFiles in current working directory:')
			path = os.getcwd() + '/' + command[1]
			files = [ f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f)) ]
			for file in files:
				print file
			print('\n')

		elif command[0] == 'quit':
			print("Now quitting")
			s.sendall('quit')
			s.close()
			sys.exit()

		else:
			print('This is not a valid command. Valid commands are \'help\', \'upload\', \'download\', \'list\', and \'quit\'. Try again.')

s.close()
