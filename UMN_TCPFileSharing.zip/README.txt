Name: Joshua Langer
Course: CSCI 4211
Term: Spring 15
Date: 4/21/15

Included with this text file are server.py, client.py, and table.txt

server.py
  * User MUST create folder, called "server", on current working directory
  * Run with the command "python server.py [port number]"
  * Handles two commands: list and quit
  * Quit should not exit the program when at least one client is still connected to the server (actually, I have had difficulty implementing this command, so it is incomplete)
  * Files to be uploaded and downloaded should be less than "SIZE", as defined as well in client.py

client.py
  * User MUST create folders on same current working directory. They may have unique names, but must be referred to as such when uploading and downloading.
  * Run with the command "python client.py [server's domain name] [server's port number]"
  * The password is the first part of the server's domain name, except for the hyphen. For example, if the client is connecting to kh4250-38.cselabs.umn.edu, then the password is kh425038.
  * If the user enters the password incorrectly, the user is returned to the command line. 
  * Handles five commands: help, upload, download, list, and quit; where "help" lists the last four commands for the user's convenience
  * upload [file name] [source folder] means that the user must access the file from its folder to be uploaded to the server's folder. An error occurs if the file name is not in said source folder.
  * download [file name] [dest folder] means that the user must specify the destination folder that the server should download the file to. An error occurs if the file does not exist in the server's folder.

table.txt
  * Stores domain names and passwords for all CSELab Unix machines, as listed in http://cselabs.umn.edu/labs/unix_machines
