/*

In this assignment we will implement 4 recursive functions two a simple calculations
and two are searches on an array provided in our header file.

We will use the standard headings here and please use the simplest approach to the 
calculations so we can spot errors more easily.

*/

#include <iostream>
#include "RecursionHeader.h"
using namespace std;

int main()
{
	// Declare array used for last two functions
	int sampleArray[] = {45, 8, 29, 98, 22, 43, 56, 34, 49, 17};
	// First declare an instance of the class through simple declaration
	Recursion r;
	// Declare a value to return from linear search
	int svalue = 0;
	// Initialize maxValue here
	int maxValue = 0;
	// For Interactive Fibbonacci Sequence
	int a = 0; 
	int b = 0;
	int n = 0;
	// For Interactive GCD
	int i = 0; 
	int j = 0;
	// For Interactive Linear Search
	int x = 0;
	// For loop counter
	int y = 0;
	
	
	// now lets find the fibonacci number of a series where:
	// a = 4
	// b = 5
	// and we want to find the fibonacci number of the 7th number in the sequence
	cout << "Fibonacci Sequence" << endl;
	cout << "a = 4, b = 5 " << endl;
	cout << "The fibonacci number for the 7th element in the sequence is : " << r.fibonacci(4,5,7) << endl;
	cout << endl;
	cin.get();
	
	//(Added) Interactive Fibonacci Sequence
	cout << "Interactive Fibonacci Sequence" << endl;
	cout << "Enter the first element : ";
	cin >> a;
	cout << "Enter the second element : ";
	cin >> b;
	cout << "Find term # : ";
	cin >> n;
	cout << "The fibonacci number at that term in the sequence is : " << r.fibonacci(a, b, n) << endl;
	cout << endl;
	cin.get();
	
	// now lets find the greatest common divisor of 81 and 127

	cout << "Greatest Common Divisor" << endl;
	cout << "The greatest common divisor of 81 and 127 is : " << r.gcd(81,127) << endl;
	cout << endl;
	cin.get();

	//(Added) Interactive GCD
	cout << "Interactive Greatest Common Divisor" << endl;
	cout << "Enter an integer : ";
	cin >> i;
	cout << "Enter a second integer : ";
	cin >> j;
	cout << "The greatest common divisor of the two integers is : " << r.gcd(i, j) << endl;
	cout << endl;
	cin.get();

	// now lets find if the value 98 is in the list sampleArray
	cout << "\nLinear Search" << endl;
	for (y = 0; y < 10; y++) 
	{
		cout << sampleArray[y] << " ";	// Prints each element in the array
	}
	
	if ((svalue = r.linearSearch(sampleArray, 0, 9, 98)) >= 0)
	{
		cout << "\nThe value " << sampleArray[svalue] << " was located at index : " << svalue << endl;
	}
	else
		cout << "\nValue not on the list" << endl;
	cin.get();

	// (Added) Interactive Linear Search
	cout << "\nInteractive Linear Search" << endl;
	cout << "Enter a number to see if it is in the list : ";
	cin >> x;
	if ((svalue = r.linearSearch(sampleArray, 0, 9, x)) >= 0)
	{
		cout << "The value " << sampleArray[svalue] << " was located at index : " << svalue << endl;
	}
	else
		cout << "Value not on the list" << endl;
	cin.get();

	// finally lets find the maximum value in a list
	cout << "\nThe maximum value in the list sampleArray is : " << r.findMaximum(sampleArray, 0, 9, maxValue) << endl;
	cin.get();

	return 0;

} // end of driver file