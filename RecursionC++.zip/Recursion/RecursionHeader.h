/* 
This class basically defines a structure onto which we have attached some data
and function prototypes for our homework assignment on recursion. We implement 4
simple recursions in this exercise. Two recursions on the enclosed list and two
recursions in which we use recursion to calculate a result
*/

class Recursion
{
public:
	Recursion();								// no arg constructor
	int fibonacci(int, int, int);				// function which calculates the fibonacci number
	int gcd(int, int);							// function which calculates the greatest common denominator
	int linearSearch(int [], int, int, int);	// function which performs a linear search
	int findMaximum(int [], int, int, int);		// function which finds maximum number in a list
};