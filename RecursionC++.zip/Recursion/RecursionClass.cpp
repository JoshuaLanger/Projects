// include project header
#include "RecursionHeader.h"
#include <iostream>
using namespace std;	// For use in GCD Function

	
// Stub the default constructor

Recursion::Recursion() {}			// stub the no arg constructor

/*
A Fibonacci sequence is defined as follows:
Given the first two numbers of a sequence we can determine any number in the sequence
which follows as the sum of the two preceding numbers in that sequence.
For example:
First number = 3
Second number = 4
Calculated third number in the sequence = 3 + 4 = 7
Calculated fourth number in the sequence (second number + third number) = 4 + 7 = 11
Calculated fifth number in the sequence (third number + fourth number) = 7 + 11 = 18

This process continues.

Our goal is to develop a recursive function to calculate the any number in the sequence
given the starting two numbers in the sequence.

Please feel free to research this a bit more on the internet.

Our function will have the following form:
a = first number in sequence
b = second number in sequence
n = position in sequence for which we want to calculate the fibonacci number

int fibonacci(a, b, n), the function returns the fibonacci number for the n'th
element in the list
*/

int Recursion::fibonacci(int a, int b, int n)
{
	if (n == 2) return b;			// base case where n is third termm
	else
	{
		int c = a + b;				// establish next term
		return fibonacci(b, c, n-1);	// add next two terms and decrement n
	}
}

/*
Given two integers: i and j there is a largest integer which can divide either of them
and return an integer result. In some cases such as i = 3 and i = 7 this integer may simply
be 1 in other cases such as i = 25 and j = 30 this integer would be 5 since 5 divides both 
25 and 30 with an integer result and no remainder.

(Added) Thus, the GCD can be calculated through a series of modulation operations, in which 
the denominator of the former operation is divided by the remainder until it equals zero.
This remainder is the GCD.

Write a recursive formulation of this problem by programming a function: int gcd(i,j)
which returns the greates common divisor of i and j
*/

int Recursion::gcd(int i, int j)
{
	int r = j % i;				// Modulo operation to find remainder
	if (r == 0) return i;		// Base case, "i" is the GCD
	else return gcd(r, i);		// Recursive case, mod r by lower number
}

/* 
given the array, sampleArray found in the header file of this project write a recursive
function which performs a linear search and returns the array index where the value
is found otherwise it returns -1 if the value has not be located.

int linearSearch(sampleArray, 0, 9, searchValue)

*/

int Recursion::linearSearch(int searchArray[], int currIndex, int lastIndex, int searchValue)
{
	if (searchValue == searchArray[currIndex]) return currIndex;
	else if (currIndex == lastIndex) return -1;
	else return linearSearch(searchArray, currIndex + 1, lastIndex, searchValue);
}

/*
Given the array sampleArray shown in the header write a recursive function that finds 
the maximum value of its elements. This function should take:
1. sampleArray as the first argument
2. initial index, 0 in this case to start search
3. final index, n-1 = 9 in this case to limit the search

The function should return the maximum value found in the array
*/

int Recursion::findMaximum(int searchArray[], int currIndex, int lastIndex, int maxValue)
{
	if (currIndex == lastIndex) return maxValue;	// Base case
	else if (searchArray[currIndex] > maxValue) 
	{
		maxValue = searchArray[currIndex];
		return findMaximum(searchArray, currIndex + 1, lastIndex, maxValue);
	}
	else return findMaximum(searchArray, currIndex + 1, lastIndex, maxValue);
}