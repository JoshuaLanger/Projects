CSCI4511W Final Project - Maze Generation and Solution

Name: Joshua Langer

ID: 4233721

x500: lange527

TA: Mark Valovage

Term: Fall 2014



Included with this are four files: mazegen.py, mazesearch.py, mazedriver.py, and example



NOTE: These files can currently be run with Python 2.7.6, as is the version on the CSE Lab machines. If you're running Python 3.x, replace line 15 of mazesearch.py with 'from queue import PriorityQueue'.



To run a demonstration of maze generation, enter the command "python mazegen.py <length> <wdith> <random bit>". It prints a randomized maze to the terminal. This is a visualization of a maze that depth-first and A* search would traverse.


<length>: The horizontal dimension of the maze.

<width>: The vertical dimension of the maze.

<random bit>: If 0, the start and finish positions are always fixed at the top-left and bottom-right corners, respectively. If 1, the start and finish positions are randomized in each trial

I recommend running the command "python mazegen.py 16 10 1"



To run a demonstration of maze solution, enter the command "python mazedriver.py <length> <width> <trials> <random bit> <filename>" It prints two tables of results to a file of your choice


<length>: The horizontal dimension of the maze. 

<width>: The vertical dimension of the maze.

<trials>: The number of executions

<random bit>: If 0, the start and finish positions are always fixed at the top-left and bottom-right corners, respectively. If 1, the start and finish positions are randomized in each trial

<filename>: Specify where you want the table results to appear. Type 'terminal' to have them printed at the terminal.


NOTE: I recommend you do not set length nor width greater than 250. Also, since a new maze is generated for each trial, if the maze size is large, the number of trials should be set relatively smaller.

Example.txt shows normal output of a run of both files.
 

