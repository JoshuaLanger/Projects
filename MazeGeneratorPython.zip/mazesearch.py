# Joshua Langer
# CSCI 4511W Final Project
# 12/15/14

# Stack data structure imported from InteractivePython.org
#    http://interactivepython.org/courselib/static/pythonds/BasicDS/stacks.html
# A* search and heuristic modified from Amit Patel of redblobgames.com
#    http://www.redblobgames.com/pathfinding/a-star/implementation.html#sec-1-4
# Priority queue imported from jcollado of StackOverflow.com
#    http://stackoverflow.com/questions/9289614/how-to-put-items-into-priority-queues/9289760#9289760

from time import clock
from random import randrange
from mazegen import Cell, Maze
from Queue import PriorityQueue

# Used for depth-first search
class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)

# Used for A* search
class MyPriorityQueue(PriorityQueue):
    def __init__(self):
        PriorityQueue.__init__(self)
        self.counter = 0

    def put(self, item, priority):
        PriorityQueue.put(self, (priority, self.counter, item))
        self.counter += 1

    def get(self, *args, **kwargs):
        _, _, item = PriorityQueue.get(self, *args, **kwargs)
        return item     

# maze is created from maze_generator
# start and finish are Cells within the maze
# where the search begins and terminates, respectively
def depthfirstsearch(maze, start, finish):
    S = Stack()
    # Initialize metrics
    max_sz = 0
    itr = 0
    S.push(start)
    # Continue until the stack is empty
    while S.size is not 0:
        Cell = S.pop()
        if Cell is finish: return max_sz, itr
        else:
            Cell.visited = 1
            for c in Cell.moves:
                if c.visited is 0:
                    S.push(c)
        # Update the metrics            
        max_sz = max(max_sz, S.size())
        itr += 1

# Manhattan Distance heuristic
def heuristic(a, b):
     (y1, x1) = a
     (y2, x2) = b
     return abs(y1 - y2) + abs(x1 - x2)

def astar(maze, start, finish):
     # Initialize metrics
     max_sz = 0
     itr = 0
     # Initialize priority queue 
     frontier = MyPriorityQueue()
     frontier.put(start, 0)
     came_from = {}
     cost_so_far = {}
     came_from[start] = None
     cost_so_far[start] = 0

     while not frontier.empty():
          CurrentCell = frontier.get()
          if CurrentCell is finish:
               return max_sz, itr
          for c in CurrentCell.moves:
               new_cost = cost_so_far[CurrentCell] + 1
               if c not in cost_so_far or new_cost < cost_so_far[c]:
                    cost_so_far[c] = new_cost
                    priority = new_cost + heuristic(finish.pos, c.pos)
                    frontier.put(c, priority)
                    came_from[c] = CurrentCell
          max_sz = max(max_sz, frontier.qsize())
          itr += 1                  

if __name__ == '__main__':
    l = 100
    w = 100
    M = Maze(l, w)
    maze = M.maze_generator()
    start = maze[randrange(w)][randrange(l)]
    finish = maze[randrange(w)][randrange(l)]
    # Reset finish if it is the same as start
    while finish is start:
         finish = maze[randrange(w)][randrange(l)]
    begin = clock()     
    m, i = depthfirstsearch(maze, start, finish)
    end = clock()
    print("===DEPTH-FIRST SEARCH===")
    print("Max stack size:",m)
    print("# of iterations:", i)
    print("Total time:", end - begin)
    M.clear_visits(maze)
    begin = clock()    
    m, i = astar(maze, start, finish)
    end = clock()
    print("===A-STAR SEARCH===")
    print("Max queue size:",m)
    print("# of iterations:", i)
    print("Total time:", end - begin)
    
    
            
            
    
    
