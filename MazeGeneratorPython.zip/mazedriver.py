# Joshua Langer
# CSCI 4511W Final Project
# 12/15/14

from time import clock
from random import randrange
from mazegen import Cell, Maze
from mazesearch import depthfirstsearch, astar

def demo(l, w, t, r, filename):
    # length and width
    length = l
    width = w
    # toggle random or fixed start and terminal Cells
    random = r
    trials = t
    dfs_table = []
    astar_table = []

    for trial in range(trials):
        M = Maze(length, width)
        maze = M.maze_generator()
        
        if random:
            start = maze[randrange(width)][randrange(length)]
            finish = maze[randrange(width)][randrange(length)]
            while finish is start:
                finish = maze[randrange(width)][randrange(length)]
        else:        
            start = maze[0][0]
            finish = maze[width-1][length-1]
            
        # Depth-first search block
        begin = clock()
        m, i = depthfirstsearch(maze, start, finish)
        end = clock()
        delta = end - begin
        dfs_table.append([trial+1, m, i, delta])              
        # A* search block
        begin = clock()
        m, i = astar(maze, start, finish)
        end = clock()
        delta = end - begin
        astar_table.append([trial+1, m, i, delta])

    # Print results to terminal
    if filename == 'terminal':
        print("Maze length: {0}".format(length))
        print("Maze width: {0}".format(width))
        print("Number of trials: {0}".format(trials))
        if random: print("Random start & finish locations: Yes")
        else: print("Random start & finish locations: No")    
        print("\n=========DEPTH-FIRST SEARCH==========")
        print("|Trial|Max Size|Iterations|Exec Time|")
        print("+-----+--------+----------+---------+")
        for i in dfs_table:
            print("|{0:<5}|{1:<8}|{2:<10}|{3:.7f}|".format(i[0], i[1], i[2], i[3]))
            print("+-----+--------+----------+---------+")
        print("\n===========A-STAR SEARCH=============")
        print("|Trial|Max Size|Iterations|Exec Time|")
        print("+-----+--------+----------+---------+")
        for i in astar_table:
            print("|{0:<5}|{1:<8}|{2:<10}|{3:.7f}|".format(i[0], i[1], i[2], i[3]))
            print("+-----+--------+----------+---------+")
     # Print results to filename       
    else:       
        with open(filename, 'w') as f:
            f.write("\nMaze length: {0}".format(length))
            f.write("\nMaze width: {0}".format(width))
            f.write("\nNumber of trials: {0}".format(trials))
            if random: f.write("\nRandom start & finish locations: Yes")
            else: f.write("\nRandom start & finish locations: No")    
            f.write("\n\n=========DEPTH-FIRST SEARCH==========")
            f.write("\n|Trial|Max Size|Iterations|Exec Time|")
            f.write("\n+-----+--------+----------+---------+")
            for i in dfs_table:
                f.write("\n|{0:<5}|{1:<8}|{2:<10}|{3:.7f}|".format(i[0], i[1], i[2], i[3]))
                f.write("\n+-----+--------+----------+---------+")
            f.write("\n\n===========A-STAR SEARCH=============")
            f.write("\n|Trial|Max Size|Iterations|Exec Time|")
            f.write("\n+-----+--------+----------+---------+")
            for i in astar_table:
                f.write("\n|{0:<5}|{1:<8}|{2:<10}|{3:.7f}|".format(i[0], i[1], i[2], i[3]))
                f.write("\n+-----+--------+----------+---------+")

        print("Results printed to", filename)            

if __name__ == '__main__':
    import sys
    length = sys.argv[1]
    width = sys.argv[2]
    trials = sys.argv[3]
    random = sys.argv[4]
    fn = sys.argv[5]
    demo(100, 100, 10, 0, fn)

