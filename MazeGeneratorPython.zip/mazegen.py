# Joshua Langer
# CSCI 4511W Final Project
# 12/15/14

# Stack data structure imported from InteractivePython.org
#    http://interactivepython.org/courselib/static/pythonds/BasicDS/stacks.html
# Pseudocode for mazegen function from mazeworks.com
#    http://www.mazeworks.com/mazegen/mazetut/index.htm
# Maze shell graphics generation modified from RosettaCode.org
#    http://rosettacode.org/wiki/Maze_generation#Python

from random import randrange

class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)

class Cell:
    """ A cell is a single spot in the maze that stores information
    on its position, adjacent squares, and where it can go"""
    def __init__(self, pos):
        self.pos = pos # tuple
        y, x = self.pos
        # Set adjacencies clockwise as all four neighbors of current cell
        # NOTE: Does NOT check to see if any are within the boundaries of the maze!
        self.adj = [(y+1, x), (y, x+1), (y-1, x), (y, x-1)]
        # moves stores all adjacent Cells that the current Cell can move to
        # Initialized as an empty list, yet expanded in maze_generator
        self.moves = []
        # "Visited" bit used for searching
        self.visited = 0

    def set_move(self, pos):
         # Sets "wall" value to 0 so movement to that square is 
         self.moves.append(pos)

class Maze:
     def __init__(self, length, width):
          self.length = length
          self.width = width

     # Resets all Cell's visited state to zero
     def clear_visits(self, maze):
          for y in range(self.width):
               for x in range(self.length):
                    maze[y][x].visited = 0

     # Generates a maze as a list of lists of Cells
     # where only one path exists between any two Cells
     def maze_generator(self):
          """ Randomly generates a maze accessible through Cells
          length is horizontal, width is vertical """
          # Initialize the maze with no possible moves
          maze = [[] for _ in range(self.width)]
          for y in range(self.width):
               for x in range(self.length):
                    maze[y].append(Cell((y,x)))
                    # Remove all adjacencies outside of the maze's boundaries
                    for _ in range(2):
                         for i in maze[y][x].adj:
                              if ((i[0] == self.width) or (i[0] == -1) or (i[1] == self.length) or (i[1] == -1)):
                                   maze[y][x].adj.remove(i)
          # Initialize a stack to hold cell locations
          CellStack = Stack()
          TotalCells = self.length * self.width
          # Call a random cell to begin the process
          CurrentCell = maze[randrange(self.width)][randrange(self.length)]
          VisitedCells = 1
          # Iterate until all cells have been visited
          while (VisitedCells < TotalCells):
               #find all neighbors of CurrentCell with all walls intact
               choose = []
               for i in CurrentCell.adj:
                    y, x = i
                    if (maze[y][x].moves == []): choose.append(maze[y][x])
               # If one or more was found...
               choose_len = len(choose)
               if choose_len is not 0:
                    # choose one randomly
                    NextCell = choose[randrange(choose_len)]
                    # allow the cells movement to each other
                    NextCell.moves.append(CurrentCell)
                    CurrentCell.moves.append(NextCell)
                    # push CurrentCell's location onto the CellStack
                    CellStack.push(CurrentCell)
                    # Switch CurrentCell to NextCell
                    CurrentCell = NextCell
                    VisitedCells += 1
               else:
                    # pop most recently entry off CellStack
                    CurrentCell = CellStack.pop()
          
          return maze
     
     # Print the layout of the board
     # Must be called AFTER maze_generator
     def print_maze(self, maze, start, finish):
          ver = [["|   "] * self.length + ['|'] for _ in range(self.width)] + [[]]
          hor = [["+---"] * self.length + ['+'] for _ in range(self.width + 1)]
          for y in range(self.width):
               for x in range(self.length):
                    for c in maze[y][x].moves:
                         cy = c.pos[0]
                         cx = c.pos[1]
                         # y positions are the same
                         if (cy == maze[y][x].pos[0]) and (maze[cy][cx].visited == 0):
                              ver[cy][cx] = "    "
                         # x positions are the same
                         elif (cx is maze[y][x].pos[1]) and (maze[cy][cx].visited == 0):
                              hor[cy][cx] = "+   " 
                    maze[y][x].visited = 1
          # Add start and finish
          for c in start.moves:
               if c.pos[1] == start.pos[1] - 1:
                    ver[start.pos[0]][start.pos[1]] = "  S "
                    break
               ver[start.pos[0]][start.pos[1]] = "| S "
          for c in finish.moves:
               if c.pos[1] == finish.pos[1] - 1:
                    ver[finish.pos[0]][finish.pos[1]] = "  F "
                    break
               ver[finish.pos[0]][finish.pos[1]] = "| F "   
          for (a, b) in zip(hor, ver):
               print(''.join(a + ['\n'] + b))
          self.clear_visits(maze)     


if __name__ == '__main__':
     import sys
     l = int(sys.argv[1])
     w = int(sys.argv[2])
     r = int(sys.argv[3])
     M = Maze(l, w)
     maze = M.maze_generator()
     # Randomize start and finish positions
     if r:
         s = maze[randrange(w)][randrange(l)]
         f = maze[randrange(w)][randrange(l)]
         if f is s:
             f = maze[randrange(w)][randrange(l)]
     # Fix start and finish positions
     else:
     	 s = maze[0][0]
         f = maze[w-1][l-1]
     M.print_maze(maze, s, f)
     
    
    
